try `make run` to compile and run!

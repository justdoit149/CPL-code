//用node建立树，fds数组保留，打开后fds[fd]->f指向树里被打开的文件（打开的时候应该复制一份指针给它。）
//对树的处理：建立一个函数，将字符串路径根据/拆解成一层层的，然后开一个指针数组（全局），返回被打开的文件/目录在第几层。*/
#include "ramfs.h"
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
typedef struct node{
  enum { FILE_NODE, DIR_NODE } type;//(储存类型，0为文件，1为目录)
  struct node **dirents; // if it's a dir, there's subentries(储存一系列指针，这些指针指向该目录的一系列子目录)
  char *content; // if it's a file, there's data content(储存文件的内容)
  int nrde; // number of subentries for dir(储存子目录的个数,含文件数。这会导致dirents数组里有空指针。但是新开的位置一定是空的，可以挂mkdir；rmdir后找到第一个空指针，然后把后面的都往前移)
  int size; // size of file(储存文件的大小)
  char *name; // it's short name(储存文件/目录名)
}node;
typedef struct FD{
  int offset;//偏移量
  int flags;//打开方式
  node *f;//文件的具体地址，从根目录出发的一个链表，一直指向最终的文件。
}FD;//FD的元素之一就是node。FD只用于文件。

FD **fds;//用1-4096这4096个数字来分配文件描述符fd
node *root;//声明root
struct node *pathnames[512];
char shortname_end[35];//假如当前目录不存在、父目录存在，那就把当前目录的目录名暂存在这里，用于处理新建文件、新建目录的情况。
int INDEX1 = 1, INDEX2 = 2;//解析路径的时候用，匡出'/'之间的内容，一个指前端一个指后端
int COUNT = 0;
bool ENDCHAR = 1;
int max(int a, int b){
  return (a > b ? a : b);
}
int min(int a, int b){
  return (a < b ? a : b);
}
bool check_char(char c){
  if(c >= 'a' && c <= 'z') return true;
  if(c >= 'A' && c <= 'Z') return true;
  if(c >= '0' && c <= '9') return true;
  if(c == '.') return true;
  return false;
}
int find_free_fds(){//可以试试有一个外部count变量，每分配一次就自增，超过4096则回绕。for循环用i = count计数一圈。借助%实现。如果时间超限可以试试改这里。
  while(1){
    COUNT = COUNT % 4096 + 1;
    if(fds[COUNT] == NULL){
      return COUNT;
    }
  }
}//遍历fds数组，寻找第一个空闲的位置以便分配fd
int find(const char *pathname){
  int count = 1;
  if(*pathname != '/') return -1;
  pathnames[0] = root;
  if(*(pathname + 1) == '\0') return 0;
  for(; *(pathname + INDEX1) != '\0'; count++){
    for(; *(pathname + INDEX1) == '/'; INDEX1++);
    if(*(pathname + INDEX1) == '\0') break;
    for(INDEX2 = INDEX1 + 1; *(pathname + INDEX2) != '/' && *(pathname + INDEX2) != '\0'; INDEX2++);
    int len = INDEX2 - INDEX1;
    int Len = min(len,34);
    char *shortname = malloc(35);
    strncpy(shortname, pathname + INDEX1, Len);
    *(shortname + Len) = '\0';
    for(int j = 0; j < pathnames[count-1]->nrde; j++){
      if(strcmp(shortname,(*(pathnames[count-1]->dirents + j))->name) == 0){
        pathnames[count] = *(pathnames[count-1]->dirents + j);
        goto FIND;
      }
    }
    for(; *(pathname + INDEX2) == '/' ; INDEX2++);
    if(*(pathname + INDEX2) != '\0'){
      INDEX1 = 1, INDEX2 = 2;
      return -1;
    }
    strcpy(shortname_end,shortname);
    INDEX1 = 1, INDEX2 = 2;
    if(*(pathname + INDEX1 - 1) == '/') ENDCHAR = 0;
    return -count-1;
    FIND:
    INDEX1 = INDEX2;
    free(shortname);
  }
  INDEX1 = 1, INDEX2 = 2;
  return count;
}//错误返回-1，当前目录不存在但父目录存在返回-count-1(这个时候count没有自增，当前目录层数是count，父目录是count-1，即-return-2)，其它情况返回count'表示在第count+1层;root为第0层。

int ropen(const char *pathname, int flags) {
  int val = find(pathname);
  if(val == -1) return -1;
  if(val < -1 && (flags & O_CREAT) == 0) return -1;
  int fd = find_free_fds();
  if(val == 0 || (val > 0 && pathnames[val-1]->type == DIR_NODE)){
    fds[fd] = malloc(sizeof(FD) + 5);
    fds[fd]->f = pathnames[max(val-1,0)];
    return fd; 
  }//打开目录。
  if(val > 0){
    fds[fd] = malloc(sizeof(FD) + 5);
    fds[fd]->flags = flags;
    fds[fd]->f = pathnames[max(val-1,0)];
    if((flags & O_APPEND) != 0){//注意：==,!=优先级比位运算符高！！！！！！
      fds[fd]->offset = fds[fd]->f->size;
    }else{
      fds[fd]->offset = 0;
    }
    if(((flags & O_TRUNC) != 0) && (flags % 4 != 0)){
      fds[fd]->offset = 0;
      free(fds[fd]->f->content);
      fds[fd]->f->content = NULL;
      fds[fd]->f->size = 0;
    }
    return fd;
  }//打开已有文件，不需要开空间、不需要命名等，只挂载上就行了。
  int count = - val - 2;//最后是创建新文件。
  if(pathnames[count]->type != DIR_NODE) return -1;
  //if(ENDCHAR == 0) return -1;
  for(int i = 0; shortname_end[i] != '\0'; i++){
    if(check_char(shortname_end[i]) == false) return -1;
  }
  if(shortname_end[32] != '\0') return -1;
  int sizeofdir = pathnames[count]->nrde;
  pathnames[count]->dirents = realloc(pathnames[count]->dirents, (sizeofdir + 1) * sizeof(node*) + 10);
  *(pathnames[count]->dirents + sizeofdir) = malloc(sizeof(node) + 5);
  (*(pathnames[count]->dirents + sizeofdir))->type = FILE_NODE ;
  (*(pathnames[count]->dirents + sizeofdir))->nrde = 0;
  (*(pathnames[count]->dirents + sizeofdir))->size = 0;
  (*(pathnames[count]->dirents + sizeofdir))->dirents = NULL;//空指针可以free
  (*(pathnames[count]->dirents + sizeofdir))->content = NULL;
  (*(pathnames[count]->dirents + sizeofdir))->name = malloc(36);
  strcpy((*(pathnames[count]->dirents + sizeofdir))->name,shortname_end);
  pathnames[count]->nrde++;
  fds[fd] = malloc(sizeof(FD) + 5);
  fds[fd]->flags = flags;
  fds[fd]->offset = 0;
  fds[fd]->f = *(pathnames[count]->dirents + sizeofdir);
  return fd;
}//会不会在没有关闭的情况下重复打开呢？先当没有写，会的话好像比较难写，每次打开都需要在fd里找有没有打开过。。。

int rclose(int fd) {
  if(fd < 1 || fd > 4096 || fds[fd] == NULL) return -1;
  free(fds[fd]);
  fds[fd] = NULL;
  return 0;
}//关闭打开的⽂件描述符，并返回 0。如果不存在⼀个打开的 fd，则返回 -1。
/*题外话：直接free(fds[fd]->f)只能释放掉f的空间，而f内的是node的指针而不是node这块空间本身，不能把一整条空间释放掉！！！*/

ssize_t rwrite(int fd, const void *buf, size_t count) {//奇数为只写，模4余2为可读可写，被4整除为只读？
  if(fd < 1 || fd > 4096 || fds[fd] == NULL || fds[fd]->f->type == DIR_NODE || fds[fd]->flags % 4 == 0) return -1;
  int d = fds[fd]->offset;
  int size = max(fds[fd]->f->size, d + count);
  if(size > fds[fd]->f->size) fds[fd]->f->content = realloc(fds[fd]->f->content, size + 1);
  memcpy(d + fds[fd]->f->content, buf, count);
  if(d > fds[fd]->f->size){
    for(int i = fds[fd]->f->size; i < d; i++){
      *(fds[fd]->f->content + i) = '\0';
    }
  }
  fds[fd]->offset = d + count;
  fds[fd]->f->size = size;
  return count;
}

ssize_t rread(int fd, void *buf, size_t count) {
  if(fd < 1 || fd > 4096 || fds[fd] == NULL || fds[fd]->f->type == DIR_NODE || fds[fd]->flags % 2 == 1) return -1;
  int d = fds[fd]->offset;
  int size = fds[fd]->f->size;
  int return_val = min(size - d, count);
  if(return_val <= 0) return 0;
  memcpy(buf, d + fds[fd]->f->content, return_val);
  fds[fd]->offset = d + return_val;
  return return_val;
}//偏移量>=文件大小：读出字节数为0，返回0；偏移量d<文件大小size，读出min = min(文件大小-偏移量，count)

off_t rseek(int fd, off_t offset, int whence) {
  if(fd < 1 || fd > 4096 || fds[fd] == NULL || fds[fd]->f->type == DIR_NODE) return -1;//或运算先判空，这样如果空就不执行第二条；否则若第二条在前，万一空则会访问空指针，导致错误
  if(whence == SEEK_SET){
    if(offset < 0) return -1;
    fds[fd]->offset = offset;
    return offset;
  }
  if(whence == SEEK_CUR){
    int offset1 = fds[fd]->offset + offset;
    if(offset1 < 0) return -1;
    fds[fd]->offset = offset1;
    return offset1;
  }
  if(whence == SEEK_END){
    int offset2 = fds[fd]->f->size + offset;
    if(offset2 < 0) return -1;
    fds[fd]->offset = offset2;
    return offset2;
  }
  return -1;//如果whence不是上述3个数，返回-1（？）
}//这个函数⽤于修改 fd 表⽰的⽂件描述符的偏移量，并返回当前⽂件的实际偏移量。此处不需要考虑偏移量超过文件大小的情况，应该在写入的时候考虑。

int rmkdir(const char *pathname) {
  int val = find(pathname);
  if(val >= -1) return -1;
  int count = - val - 2;//父目录的所在层数
  if(pathnames[count]->type != DIR_NODE) return -1;
  for(int i = 0; shortname_end[i] != '\0'; i++){
    if(check_char(shortname_end[i]) == false) return -1;
  }
  if(shortname_end[32] != '\0') return -1;
  int sizeofdir = pathnames[count]->nrde;
  pathnames[count]->dirents = realloc(pathnames[count]->dirents, (sizeofdir + 1) * sizeof(node*) + 10);
  *(pathnames[count]->dirents + sizeofdir) = malloc(sizeof(node) + 5);
  (*(pathnames[count]->dirents + sizeofdir))->type = DIR_NODE;
  (*(pathnames[count]->dirents + sizeofdir))->nrde = 0;
  (*(pathnames[count]->dirents + sizeofdir))->dirents = NULL;//空指针可以free
  (*(pathnames[count]->dirents + sizeofdir))->content = NULL;
  (*(pathnames[count]->dirents + sizeofdir))->name = malloc(36);
  strcpy((*(pathnames[count]->dirents + sizeofdir))->name,shortname_end);
  (pathnames[count]->nrde)++;
  return 0;
}

void remove(int val){
  int position_of_NULL;
  for(int i = 0; i < pathnames[val-2]->nrde; i++){
    if(*(pathnames[val-2]->dirents + i) == pathnames[val-1]){
      position_of_NULL = i;
      *(pathnames[val-2]->dirents + i) = NULL;
      break;
    }
  }
  free(pathnames[val-1]->name);
  free(pathnames[val-1]->dirents);
  free(pathnames[val-1]->content);
  free(pathnames[val-1]);
  *(pathnames[val-2]->dirents + position_of_NULL) = *(pathnames[val-2]->dirents + pathnames[val-2]->nrde - 1);//realloc分配的时候可能不是分配完整一块，而是不同位置的好几块，这种情况怎么办？？？
  (pathnames[val-2]->nrde)--;
  pathnames[val-2]->dirents = realloc(pathnames[val-2]->dirents, pathnames[val-2]->nrde * sizeof(node*) + 10);
  return;
}

int rrmdir(const char *pathname){
  int val = find(pathname);
  if(val <= 0 || pathnames[val-1]->type != DIR_NODE || pathnames[val-1]->nrde != 0) return -1; 
  remove(val);
  return 0;
}

int runlink(const char *pathname) {
  int val = find(pathname);
  if(val <= 0 || pathnames[val-1]->type != FILE_NODE) return -1; 
  remove(val);
  return 0;
}

void init_ramfs(){//初始化：开一块空间
  root = malloc(sizeof(node) + 5);
  root->type = 1;
  root->dirents = NULL;
  root->nrde = 0; 
  root->name = malloc(5);
  strcpy(root->name,"/");
  fds = malloc(8 * 4100 + 10);
  for(int i = 0; i < 4100; i++){
    fds[i] = NULL;
  }
  return;
}
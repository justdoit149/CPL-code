#include "ramfs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifdef LOCAL
#include <assert.h>
#else
#define assert(cond)                                                           \
  do {                                                                         \
    if (cond)                                                                  \
      ;                                                                        \
    else {                                                                     \
      puts("false");                                                           \
      exit(EXIT_SUCCESS);                                                      \
    }                                                                          \
  } while (0)
#endif
#define KB *1024
#define MB KB * 1024
#define SZ (384 MB)

#define test(func, expect, ...) assert(func(__VA_ARGS__) == expect)
#define succopen(var, ...) assert((var = ropen(__VA_ARGS__)) >= 0)
#define failopen(var, ...) assert((var = ropen(__VA_ARGS__)) == -1)

static int md[4096];
static int mpos[4096];
static uint8_t buf[1 MB];
static uint8_t ref[SZ + 1];

static void gen_rand_mb() {
  uint32_t *b = (uint32_t *)buf;
  for (int i = 0; i < 1 MB / 4; i++) {
    b[i] = rand();
  }
}

static void gen_rand_96kb() {
  uint32_t *b = (uint32_t *)buf;
  for (int i = 0; i < 96 KB / 4; i++) {
    b[i] = rand();
  }
}
int main() {
  srand(time(NULL));
  init_ramfs();

  int fd;
  succopen(fd, "/bigfile", O_CREAT | O_RDWR);
  test(rseek, SZ - 1, fd, SZ - 1, SEEK_END);
  test(rwrite, 1, fd, "\0", 1);
  test(rseek, SZ, fd, 0, SEEK_CUR);
  test(rseek, 0, fd, 0, SEEK_SET);

  /* check padding */
  test(rread, SZ, fd, ref, SZ);
  for (int i = 0; i < SZ; i++) {
    assert(ref[i] == 0);
  }
  test(rclose, 0, fd);

  /* write with one fd, with seek_cur */
  succopen(fd, "/bigfile", O_RDWR);
  test(rseek, 0, fd, 0, SEEK_CUR);
  for (int j = 0; j < 384; j++) {
    gen_rand_mb();
    test(rwrite, 1 MB, fd, buf, 1 MB);
    memcpy(ref + j MB, buf, 1 MB);
  }
  test(rseek, 0, fd, 0, SEEK_SET);
  for (int j = 0; j < 384; j++) {
    test(rread, 1 MB, fd, buf, 1 MB);
    assert(memcmp(ref + j MB, buf, 1 MB) == 0);
  }
  test(rclose, 0, fd);

  /* write with 4096 fd sequentially */
  for (int i = 0; i < 3; i++) {
    /* open and seek */
    for (int j = 0; j < 4096; j++) {
      succopen(md[j], "/bigfile", O_RDWR);
      mpos[j] = rand() % (384 MB - 96 KB);
      test(rseek, mpos[j], md[j], mpos[j], SEEK_SET);
    }
    /* rand and write 96 KB each */
    for (int j = 0; j < 4096; j++) {
      gen_rand_96kb();
      test(rwrite, 96 KB, md[j], buf, 96 KB);
      memcpy(ref + mpos[j], buf, 96 KB);
    }

    /* seek */
    for (int j = 0; j < 4096; j++) {
      mpos[j] = rand() % (384 MB - 96 KB);
      test(rseek, mpos[j], md[j], mpos[j], SEEK_SET);
    }
    /* read */
    for (int j = 0; j < 4096; j++) {
      test(rread, 96 KB, md[j], buf, 96 KB);
      assert(memcmp(ref + mpos[j], buf, 96 KB) == 0);
    }
    for (int j = 0; j < 4096; j++) {
      test(rclose, 0, md[j]);
    }
  }

  /* do you free? */
  for (int i = 0; i < 16 MB; i++) {
    succopen(fd, "/bigfile", O_RDONLY);
    test(rclose, 0, fd);
  }
  puts("kdshfuiehf98372hmjdsfb2820938746287g");
}

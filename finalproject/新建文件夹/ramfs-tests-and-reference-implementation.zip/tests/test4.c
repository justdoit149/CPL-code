#include "ramfs.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#ifdef LOCAL
#include <assert.h>
#else
#define assert(cond)                                                           \
  do {                                                                         \
    if (cond)                                                                  \
      ;                                                                        \
    else {                                                                     \
      puts("false");                                                           \
      exit(EXIT_SUCCESS);                                                      \
    }                                                                          \
  } while (0)
#endif
#define SCALE 1024

static int notin(int fd, int *fds, int n) {
  for (int i = 0; i < n; i++) {
    if (fds[i] == fd) return 0;
  }
  return 1;
}

static int genfd(int *fds, int n) {
  for (int i = 0; i < 4096; i++) {
    if (notin(i, fds, n))
      return i;
  }
  return -1;
}

static uint8_t alphabet[SCALE * 2];
static int fd[SCALE];
static uint8_t buf[SCALE][SCALE * 2];

static void openall_succ(int flag) {
  char name[34];
  for (int i = 0; i < SCALE; i++) {
    sprintf(name, "/thisisfile0123456789ABCDEFGH%04d", i);
    assert((fd[i] = ropen(name, flag)) >= 0);
  }
}

static void openall_fail(int flag) {
  char name[34];
  for (int i = 0; i < SCALE; i++) {
    sprintf(name, "/thisisfile0123456789ABCDEFGH%04d", i);
    assert((fd[i] = ropen(name, flag)) == -1);
  }
}

static void readall(int len, int expect) {
  for (int i = 0; i < SCALE; i++) {
    assert(rread(fd[i], buf[i], len) == expect);
  }
}

static void closeall(int expect) {
  for (int i = 0; i < SCALE; i++) {
    assert(rclose(fd[i]) == expect);
  }
}

static void writeall(int off) {
  for (int i = 0; i < SCALE; i++) {
    assert(rwrite(fd[i], alphabet + ((i + off) % SCALE), 1) == 1);
  }
}

static void writeall_fail(int off) {
  for (int i = 0; i < SCALE; i++) {
    assert(rwrite(fd[i], alphabet + ((i + off) % SCALE), 1) == -1);
  }
}

static void seekall(int off, int whence, int expect) {
  for (int i = 0; i < SCALE; i++) {
    assert(rseek(fd[i], off, whence) == expect);
  }
}

int main() {
  /* init alphabet */
  for (int i = 0; i < SCALE * 2; i++) alphabet[i] = i & 0xff;
  init_ramfs();
  assert(rread(-100000000, buf[0], 1) == -1);
  openall_succ(O_CREAT | O_RDWR | O_WRONLY);  // can't read
  readall(SCALE, -1);
  for (int i = 0; i < SCALE; i++) {
    seekall(i, SEEK_SET, i);
    for (int j = 0; j < SCALE; j++) {
      writeall(j);
    }
    seekall(0, SEEK_END, SCALE + i);
  }
  seekall(0, SEEK_END, 2 * SCALE - 1);
  closeall(0);
  closeall(-1);
  openall_succ(O_RDONLY);
  readall(3 * SCALE, 2 * SCALE - 1);
  for (int i = 0; i < SCALE; i++) {
    assert(memcmp(buf[i] + SCALE - 1, alphabet + i, SCALE) == 0);
    for (int j = 0; j < SCALE - 1; j++) {
      assert(buf[i][j] == alphabet[i]);
    }
  }
  closeall(0);
  for (int i = 0; i < SCALE; i++) {
    openall_succ(O_APPEND | O_RDWR);
    readall(SCALE, 0);  // at rear
    writeall(i);
    closeall(0);
  }

  memset(buf, 0, sizeof(buf));
  openall_succ(O_RDONLY);
  seekall(0, SEEK_END, 3 * SCALE - 1);
  seekall(2 * SCALE - 1, SEEK_SET, 2 * SCALE - 1);
  readall(2 * SCALE, SCALE);
  for (int i = 0; i < SCALE; i++) {
    assert(memcmp(buf[i], alphabet + i, SCALE) == 0);
  }
  closeall(0);
  puts("vcdnjkvn8u32hr7fh9823hkj2021893");
}


#include "ramfs.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#ifdef LOCAL
#include <assert.h>
#else
#define assert(cond)                                                           \
  do {                                                                         \
    if (cond)                                                                  \
      ;                                                                        \
    else {                                                                     \
      puts("false");                                                           \
      exit(EXIT_SUCCESS);                                                      \
    }                                                                          \
  } while (0)
#endif
#define KB *1024
#define MB KB * 1024
#define SZ (384 MB)

#define test(func, expect, ...) assert(func(__VA_ARGS__) == expect)
#define succopen(var, ...) assert((var = ropen(__VA_ARGS__)) >= 0)
#define failopen(var, ...) assert((var = ropen(__VA_ARGS__)) == -1)

static const char alphabet[] =
    "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.";
static int cnt = 0;

/* save names. files[0] = "/", ... to < 65535 */
static char files[65536][1024];

static void gen_name(char *dest, int len) {
  int m = (int)strlen(alphabet);
  for (int i = 0; i < len; i++) {
    dest[i] = alphabet[rand() % m];
  }
  dest[len] = 0;
}

static void bintree(char *pwd, int level) {
  strcpy(files[cnt], pwd);
  cnt++;
  if (level == 0)
    return;
  int len = (int)strlen(pwd);
  char *l = malloc(len + 34);
  char *r = malloc(len + 34);
  strcpy(l, pwd);
  strcpy(r, pwd);
  l[len] = r[len] = '/';
  gen_name(l + len + 1, 32);
  gen_name(r + len + 1, 32);
  test(rmkdir, 0, l);
  test(rmkdir, 0, r);
  bintree(l, level - 1);
  bintree(r, level - 1);
  free(l);
  free(r);
}

int main() {
  srand(time(NULL));
  init_ramfs();

  /* linear, 100 times */
  for (int t = 0; t < 100; t++) {
    char linear[1024] = "/a";
    for (int i = 1; i < 500; i++) {
      test(rmkdir, 0, linear);
      linear[2 * i] = '/';
      gen_name(linear + i * 2 + 1, 1);
    }
    test(rmkdir, 0, linear);
    for (int i = 499; i >= 1; i--) {
      test(rrmdir, 0, linear);
      linear[2 * i] = 0;
    }
    test(rrmdir, 0, linear);
  }

  /* random 15 level binary tree, 10 times */
  for (int t = 0; t < 10; t++) {
    cnt = 0;
    bintree("/", 15);
    for (int i = 65534; i > 0; i--) {
      test(rrmdir, 0, files[i]);
    }
  }
  test(rrmdir, -1, "/");
  
  /* spanning, lot of nodes */
  /* will it be super slow? */
  for (int i = 0; i < 8192; i++) {
    files[i][0] = '/';
    gen_name(files[i] + 1, 32);
    test(rmkdir, 0, files[i]);
  }
  for (int i = 8191; i >= 0; i--) {
    test(rrmdir, 0, files[i]);
  }
  for (int i = 0; i < 8192; i++) {
    test(rrmdir, -1, files[i]);
  }

  puts("23984u98fdfnjdnfzxcv23nmnsdgou823r");
}

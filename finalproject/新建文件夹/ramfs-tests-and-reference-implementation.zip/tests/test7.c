#include "ramfs.h"
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef LOCAL
#include <assert.h>
#else
#define assert(cond)                                                           \
  do {                                                                         \
    if (cond)                                                                  \
      ;                                                                        \
    else {                                                                     \
      puts("false");                                                           \
      exit(EXIT_SUCCESS);                                                      \
    }                                                                          \
  } while (0)
#endif
#define KB * 1024
#define MB KB * 1024
#define SZ (384 MB)

#define test(func, expect, ...) assert(func(__VA_ARGS__) == expect)
#define succopen(var, ...) assert((var = ropen(__VA_ARGS__)) >= 0)
#define failopen(var, ...) assert((var = ropen(__VA_ARGS__)) == -1)

static int fd;
static int md[16];
static int mpos[16];
static uint8_t buf[1 MB];
static uint8_t ref[SZ + 1];

static void gen_rand_mb() {
  uint32_t *b = (uint32_t *)buf;
  for (int i = 0; i < 1 MB / 4; i++) {
    b[i] = rand();
  }
}

int main() {
  srand(time(NULL));
  init_ramfs();

  int fd;
  succopen(fd, "/bigfile", O_CREAT | O_RDWR);
  /* padding, just kidding */
  test(rseek, SZ - 1, fd, SZ - 1, SEEK_END);
  test(rseek, 0, fd, 0, SEEK_END);
  /* padding, truely */
  test(rseek, SZ - 1, fd, SZ - 1, SEEK_END);
  test(rwrite, 1, fd, "\0", 1);
  test(rseek, SZ, fd, 0, SEEK_CUR);
  test(rseek, 0, fd, 0, SEEK_SET);

  /* check padding */
  test(rread, SZ, fd, ref, SZ);
  for (int i = 0; i < SZ; i++) {
    assert(ref[i] == 0);
  }
  test(rclose, 0, fd);

  /* write with one fd for 5 rounds, with seek_cur */
  for (int i = 0; i < 3; i++) {
    succopen(fd, "/bigfile", O_RDWR);
    test(rseek, 0, fd, 0, SEEK_CUR);
    int cur_pos = 0;
    for (int j = 0; j < 384; j++) {
      gen_rand_mb();
      int pos = rand() % (383 MB);
      test(rseek, cur_pos, fd, 0, SEEK_CUR);
      test(rseek, pos, fd, pos - cur_pos, SEEK_CUR);
      test(rwrite, 1 MB, fd, buf, 1 MB);
      memcpy(ref + pos, buf, 1 MB);
      cur_pos = pos + 1 MB;
    }
    test(rseek, 0, fd, 0, SEEK_SET);
    for (int j = 0; j < 384; j++) {
      test(rread, 1 MB, fd, buf, 1 MB);
      assert(memcmp(ref + j MB, buf, 1 MB) == 0);
    }
    test(rclose, 0, fd);
  }

  /* write with 384 fd sequentially */
  for (int i = 0; i < 3; i++) {
    /* open and seek */
    for (int j = 0; j < 16; j++) {
      succopen(md[j], "/bigfile", O_RDWR);
      mpos[j] = rand() % (360 MB);
      test(rseek, mpos[j], md[j], mpos[j], SEEK_SET);
    }
    /* rand and write 24 MB each */
    for (int j = 0; j < 16; j++) {
      for (int k = 0; k < 24; k++) {
        gen_rand_mb();
        test(rwrite, 1 MB, md[j], buf, 1 MB);
        memcpy(ref + mpos[j] + k MB, buf, 1 MB);
      }
    }
    /* seek */
    for (int j = 0; j < 16; j++) {
      mpos[j] = rand() % (360 MB);
      test(rseek, mpos[j], md[j], mpos[j], SEEK_SET);
    }
    /* read */
    for (int j = 0; j < 16; j++) {
      for (int k = 0; k < 24; k++) {
        test(rread, 1 MB, md[j], buf, 1 MB);
        assert(memcmp(ref + mpos[j] + k MB, buf, 1 MB) == 0);
      }
    }
    for (int j = 0; j < 16; j++) {
      test(rclose, 0, md[j]);
    }
  }
  /* rdonly, so not truncated */
  succopen(fd, "/bigfile", O_RDONLY);
  test(rread, 1 MB, fd, buf, 1 MB);
  assert(memcmp(buf, ref, 1 MB) == 0);
  test(rseek, SZ, fd, 0, SEEK_END);
  
  int fd1;
  /* another open, at end */
  succopen(fd1, "/bigfile", O_APPEND | O_RDWR);

  int fd2;
  /* another open, truncate */
  succopen(fd2, "/bigfile", O_TRUNC | O_WRONLY | O_RDWR);
  test(rseek, 0, fd, 0, SEEK_END);

  /* write a byte with fd1 */
  test(rwrite, 1, fd1, "\0", 1);
  /* should be SZ + 1 bytes */
  /* because fd's offset at SZ */
  test(rseek, SZ + 1, fd1, 0, SEEK_END);
  /* and of course, all 0 */
  test(rseek, 0, fd1, 0, SEEK_SET);
  test(rread, SZ + 1, fd1, ref, SZ + 1);
  for (int i = 0; i < SZ + 1; i++) {
    assert(ref[i] == 0);
  }
  test(rclose, 0, fd);
  test(rclose, 0, fd1);
  test(rclose, 0, fd2);
  test(runlink, 0, "/bigfile");

  /* create big file over and over, then delete */
  /* one */
  succopen(fd, "/bigfile1", O_CREAT | O_RDWR);
  test(rseek, SZ - 1, fd, SZ - 1, SEEK_END);
  test(rwrite, 1, fd, "\0", 1);
  test(rclose, 0, fd);
  test(runlink, 0, "/bigfile1");

  /* two */
  succopen(fd, "/bigfile2", O_CREAT | O_RDWR);
  test(rseek, SZ - 1, fd, SZ - 1, SEEK_END);
  test(rwrite, 1, fd, "\0", 1);
  test(rclose, 0, fd);
  test(runlink, 0, "/bigfile2");

  /* three */
  succopen(fd, "/bigfile3", O_CREAT | O_RDWR);
  test(rseek, SZ - 1, fd, SZ - 1, SEEK_END);
  test(rwrite, 1, fd, "\0", 1);
  test(rclose, 0, fd);
  test(runlink, 0, "/bigfile3");

  /* boom! */
  succopen(fd, "/bigfile4", O_CREAT | O_RDWR);
  test(rseek, SZ - 1, fd, SZ - 1, SEEK_END);
  test(rwrite, 1, fd, "\0", 1);
  test(rclose, 0, fd);
  test(runlink, 0, "/bigfile4");
  
  puts("if38947nfjdsnafkjlndsaf87u3h2fljkbaslfh");
}

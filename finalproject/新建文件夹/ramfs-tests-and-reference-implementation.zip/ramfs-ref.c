#include <assert.h>
#include <ctype.h>
#include <endian.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
/* modify this file freely */
#define NRFD 4096
char *strdup(const char *);

char namebuf[2048];
char *getname(const char *pathname) {
  sprintf(namebuf, "fs/%s", pathname);
  return namebuf;
}

int ropen(const char *pathname, int flags) {
  if ((flags & O_RDWR) && (flags & O_WRONLY)) {
    flags ^= O_RDWR;
  }
  int append = 0;
  if (flags & O_APPEND) {
    flags ^= O_APPEND;
    append = 1;
  }
  int ret = open(getname(pathname), flags, 0644);
  if (append) lseek(ret, 0, SEEK_END);
  return ret;
}

int rclose(int fd) {
  return close(fd);
}

ssize_t rwrite(int fd, const void *buf, size_t count) {
  return write(fd, buf, count);
}

ssize_t rread(int fd, void *buf, size_t count) {
  return read(fd, buf, count);
}

off_t rseek(int fd, off_t offset, int whence) {
  return lseek(fd, offset, whence);
}

int rmkdir(const char *pathname) {
  return mkdir(getname(pathname), 0755);
}

int rrmdir(const char *pathname) {
  return rmdir(getname(pathname));
}

int runlink(const char *pathname) {
  return unlink(getname(pathname));
}

void init_ramfs() {}

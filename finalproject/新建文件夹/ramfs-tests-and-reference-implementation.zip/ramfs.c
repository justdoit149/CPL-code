#include "ramfs.h"
#include <assert.h>
#include <ctype.h>
#include <endian.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
/* modify this file freely */
#define NRFD 4096
char *strdup(const char *);

typedef struct node {
  char *name;
  struct node **dirents; // if DNODE
  int nrde;
  void *content;
  int size;
  enum { FNODE, DNODE } type;
} node;

typedef struct FD {
  bool used;
  int offset;
  int flags;
  node *f;
} FD;

node root;
FD fdesc[NRFD];

node *find(const char *pathname) {
  if (!pathname[0])
    return &root;
  if (pathname[0] != '/')
    return NULL;
  char *path = strdup(pathname);
  char *base = strtok(path, "/");
  node *now = &root;
  while (base) {
    int i;
    int nrde = now->nrde;
    for (i = 0; i < nrde; i++) {
      if (strcmp(now->dirents[i]->name, base) != 0)
        continue;
      now = now->dirents[i];
      break;
    }
    if (i == nrde) {
      free(path);
      return NULL;
    }
    base = strtok(NULL, "/");
  }
  free(path);
  return now;
}

node *findparent(const char *pathname) {
  char *path = strdup(pathname);
  int len = (int)strlen(path);
  while (path[len - 1] == '/' && len > 1)
    len--;
  for (int i = len - 1; i >= 0; i--) {
    if (path[i] == '/') {
      path[i] = 0;
      break;
    }
  }
  node *n = find(path);
  free(path);
  return n;
}

/* return an allocated string containing basename. need free */
char *basename(const char *pathname) {
  int len = (int)strlen(pathname);
  char *path = strdup(pathname);
  char *ret = NULL;
  while (path[len - 1] == '/' && len > 1) {
    path[len - 1] = 0;
    len--;
  }
  for (int i = len - 1; i >= 0; i--) {
    if (path[i] == '/') {
      ret = strdup(path + i + 1);
      break;
    }
  }
  free(path);
  return ret;
}

bool checkbase(const char *basename) {
  int len = (int)strlen(basename);
  if (len <= 0 || len > 32)
    return false;
  for (int i = 0; i < len; i++) {
    if (!isalpha(basename[i]) && !isdigit(basename[i]) && basename[i] != '.')
      return false;
  }
  return true;
}

/* create pathname and open it at i. if parent doesn't exist, return -1 */
int fcreat(const char *pathname, int i, int flags) {
  if (find(pathname))
    return -2;
  node *n = findparent(pathname);
  if (!n)
    return -1;
  char *base = basename(pathname);
  if (!checkbase(base)) {
    free(base);
    return -1;
  }
  n->dirents = realloc(n->dirents, (n->nrde + 1) * sizeof(node *));
  n->nrde++;
  n = n->dirents[n->nrde - 1] = malloc(sizeof(node));
  n->name = base;
  n->type = FNODE;
  n->nrde = 0;
  n->dirents = NULL;
  n->size = 0;
  n->content = malloc(1);
  fdesc[i].flags = flags;
  fdesc[i].offset = 0;
  fdesc[i].used = 1;
  fdesc[i].f = n;
  return i;
}

int ropen(const char *pathname, int flags) {
  int i = 0;
  for (i = 0; i < NRFD; i++) {
    if (!fdesc[i].used)
      break;
  }
  if (flags & O_CREAT) {
    int ret = fcreat(pathname, i, flags);
    if (ret != -2)
      return ret;
  }
  node *n = find(pathname);
  if (!n)
    return -1;
  if (n->type == DNODE) {
    fdesc[i].used = true;
    fdesc[i].f = n;
    return i;
  }
  if (flags & O_TRUNC && (flags & (O_RDWR || O_WRONLY))) {
    n->size = 0;
    n->content = realloc(n->content, 1);
  }
  fdesc[i].used = true;
  fdesc[i].offset = (flags & O_APPEND) ? n->size : 0;
  fdesc[i].f = n;
  fdesc[i].flags = flags;
  return i;
}

int rclose(int fd) {
  if (fd < 0 || fd >= 4096 || !fdesc[fd].used)
    return -1;
  fdesc[fd].used = false;
  return 0;
}

ssize_t rwrite(int fd, const void *buf, size_t count) {
  if (fd < 0 || fd >= 4096 || !fdesc[fd].used)
    return -1;
  if (!(fdesc[fd].flags & O_WRONLY) && !(fdesc[fd].flags & O_RDWR))
    return -1;
  node *n = fdesc[fd].f;
  if (n->type == DNODE)
    return -1;
  off_t off = fdesc[fd].offset;
  int size = n->size;
  if ((int)(off + count) > n->size) {
    n->size = (int)(off + count);
    n->content = realloc(n->content, n->size);
    memset(n->content + size, 0, n->size - size);
  }
  memcpy(n->content + off, buf, count);
  fdesc[fd].offset += (int)count;
  return (ssize_t)count;
}

ssize_t rread(int fd, void *buf, size_t count) {
  if (fd < 0 || fd >= 4096 || !fdesc[fd].used)
    return -1;
  if (fdesc[fd].flags & O_WRONLY)
    return -1;
  node *n = fdesc[fd].f;
  if (n->type == DNODE)
    return -1;
  off_t off = fdesc[fd].offset;
  if ((int)(off + count) > n->size) {
    count = (int)(n->size - off);
  }
  memcpy(buf, n->content + off, count);
  fdesc[fd].offset += (int)count;
  return (ssize_t)count;
}

off_t rseek(int fd, off_t offset, int whence) {
  if (fd < 0 || fd >= 4096 || !fdesc[fd].used)
    return -1;
  int ret;
  switch (whence) {
  case SEEK_SET:
    ret = (int)offset;
    break;
  case SEEK_CUR:
    ret = fdesc[fd].offset + (int)offset;
    break;
  case SEEK_END:
    ret = (int)(fdesc[fd].f->size + offset);
    break;
  default:
    assert(0);
  }
  if (ret < 0)
    return -1;
  fdesc[fd].offset = ret;
  return ret;
}

int rmkdir(const char *pathname) {
  if (find(pathname))
    return -1;
  node *n = findparent(pathname);
  if (!n)
    return -1;
  if (n->type == FNODE)
    return -1;
  char *base = basename(pathname);
  if (!checkbase(base))
    return -1;
  n->dirents = realloc(n->dirents, (n->nrde + 1) * sizeof(node *));
  n->nrde++;
  n = n->dirents[n->nrde - 1] = malloc(sizeof(node));
  n->name = base;
  n->type = DNODE;
  n->nrde = 0;
  n->dirents = malloc(sizeof(node *));
  n->size = 0;
  return 0;
}

int rrmdir(const char *pathname) {
  node *self = find(pathname);
  if (!self || (self == &root))
    return -1;
  if (self->type != DNODE)
    return -1;
  if (self->nrde != 0)
    return -1;
  node *parent = findparent(pathname);
  free(self->dirents);
  free(self->name);
  int i;
  for (i = 0; i < parent->nrde; i++) {
    if (self == parent->dirents[i])
      break;
  }
  for (; i < parent->nrde - 1; i++) {
    parent->dirents[i] = parent->dirents[i + 1];
  }
  parent->dirents = realloc(parent->dirents, sizeof(node *) * parent->nrde);
  parent->nrde--;
  return 0;
}

int runlink(const char *pathname) {
  node *self = find(pathname);
  if (!self)
    return -1;
  if (self->type != FNODE)
    return -1;
  node *parent = findparent(pathname);
  free(self->content);
  free(self->name);
  int i;
  for (i = 0; i < parent->nrde; i++) {
    if (self == parent->dirents[i])
      break;
  }
  for (; i < parent->nrde - 1; i++) {
    parent->dirents[i] = parent->dirents[i + 1];
  }
  parent->dirents = realloc(parent->dirents, sizeof(node *) * parent->nrde);
  parent->nrde--;
  return 0;
}

void init_ramfs() {
  root.name = "/";
  root.type = DNODE;
  root.dirents = malloc(sizeof(node *) * 1);
  root.nrde = 0;
}
